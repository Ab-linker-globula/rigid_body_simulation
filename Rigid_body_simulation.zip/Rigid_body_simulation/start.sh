#!/bin/bash


python data/open_blender.py
