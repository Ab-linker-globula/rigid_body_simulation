#!/usr/bin/env python3

import subprocess
import sys
import os
import time



#################___REPLACE_TO CONFIG___________##########################
repeat = 100  ######################
start_len_of_linker = 1   ##########
end_len_of_linker = 7   ##############
start_layers = 1   ###############
end_layers = 100   #################
################__________REPLACE_______#########################







path = os.path.abspath(os.path.dirname(__file__))


path_to_file_with_result = os.path.join(os.path.split(path)[0],'result.txt')

len_linker_path_to_file= os.path.join(os.path.dirname(__file__),'len_linker.txt') 
layer_path_to_file= os.path.join(os.path.dirname(__file__),'layer.txt')
path_repeat = os.path.join(os.path.dirname(__file__),'repeat.txt')
path_to_blendfile= os.path.join(os.path.dirname(__file__),'start.blend')      
path_to_scriptforblender = os.path.join(os.path.dirname(__file__),'script_for_blender_279.py')
path_to_output_file = os.path.join(os.path.dirname(__file__),'blend.txt')
path_radians = os.path.join(os.path.dirname(__file__),'radians.txt')



   


################__________radians___________##################
f = open( path_radians , 'w')
f.write('0.034')
f.close()

###############______________repeat__________###############
repe = str(repeat)
f = open( path_repeat, 'w')
f.write(repe)
f.close()


#################____________linker_____________###############
linker= start_len_of_linker -1
linker_dif = end_len_of_linker - start_len_of_linker + 1
for lin in range(linker_dif):
    linker += 1
    a=str(linker)
    
    f1=open(len_linker_path_to_file, 'w')
    f1.write(a)
    f1.close()

    dif_layers = end_layers - start_layers + 1       
    layer = start_layers-1 
    for number in range(dif_layers):

##############__________layer_______________######################      
      layer += 1
      la = str(layer)
      f2=open(layer_path_to_file, 'w')
      f2.write(la)
      f2.close() 
      
###############______________blend.txt__________###############
      f = open( path_to_output_file, 'w')
      f.write('')
      f.close()

    
      path_popen = str("blender  " + path_to_blendfile + " --python  " + path_to_scriptforblender)
      p = subprocess.Popen(path_popen, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT) 

      for line in p.stdout.readlines():
          print line,
      retval = p.wait() 

      
      
      letters = 0 
       
      f= open(path_to_output_file, 'r')
      for line in f: 
        letters = len(line)    
      if letters == 0: 
            f.close()  
            break       
      else:        
            f2 = open( path_to_file_with_result, 'a+')
            f2.write('\n')
            f2.write('\n')
            f2.write('number of monomers = ')
            f2.write(str(layer))
            f2.write('\n')    
            f2.write('number of spheres in the linker (lenght of linker) = ')
            f2.write(str(linker))  
            f2.write('\n')  
            f2.write(' number of successful runs out of  ')
            f2.write(str(repeat))     
            f2.write(' = ')
            f2.write(str(letters))
            from time import gmtime, strftime
            f2.write(strftime(" %Y-%m-%d %H:%M:%S", gmtime()))            
            f2.close()
            f.close()
       

      path_to = 'gedit '+path_to_file_with_result
      p = subprocess.Popen(path_to, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
      print(str(path_to))

